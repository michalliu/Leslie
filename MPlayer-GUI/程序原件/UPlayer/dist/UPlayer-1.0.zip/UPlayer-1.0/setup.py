#!/usr/bin/env python
#-*- coding:utf-8 -*-

from distutils.core import setup

setup(name='UPlayer',
      version='1.0',
      description='A Simple Mplayer GUI Program',
      author= u'朱春来(zhubuntu)',
      author_email = 'pythonisland@gmail.com',
      url = 'www.python.org',
      py_modules=['uplayer','install','uninstall'])
